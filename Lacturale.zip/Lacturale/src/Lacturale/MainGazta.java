package Lacturale;

public class MainGazta {
    public static void main(String[] args) {
        Gazta g = new Gazta();
    	g.lortuPisua();
    }
}
